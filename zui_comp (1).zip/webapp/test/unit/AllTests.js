sap.ui.define([
	"celsa/zui_comp/test/unit/controller/App.controller"
], function () {
	"use strict";
});